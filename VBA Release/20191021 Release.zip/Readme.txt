FocusMe for Outlook - VBA Version

Read this instructions first.

1) Download the latest Release zip file (e.g. 20191017 Release.zip) - the latest will be the most recent date
	- Download the file to an easily accessible folder, e.g. your Desktop
2) Open the Zip file (by double clicking on the file once it has been downloaded to your local PC) and read the Installation Instructions.pdf

It's very important to download the ZIP file to your PC and install from there.  Some Windows security settings limit the ability to download binary files (e.g. the VBAProject.OTM file).

Last Updated:
2019-10-20

For questions; please send email to support@ceptara.com